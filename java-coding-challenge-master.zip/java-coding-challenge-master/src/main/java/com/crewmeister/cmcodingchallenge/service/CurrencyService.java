package com.crewmeister.cmcodingchallenge.service;

import java.io.Reader;
import java.io.StringReader;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

import com.crewmeister.cmcodingchallenge.entity.Currency;
import com.crewmeister.cmcodingchallenge.entity.CurrencyConversionRates;
import com.crewmeister.cmcodingchallenge.repository.CurrencyConversionRateRepository;
import com.crewmeister.cmcodingchallenge.repository.CurrencyRepository;
import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;

@Service
public class CurrencyService {

	private static Logger logger = LoggerFactory.getLogger(CurrencyService.class);

	@Autowired
	private CurrencyRepository currencyRepo;

	@Autowired
	private CurrencyConversionRateRepository conversionRepo;

	private final String URL = "https://api.statistiken.bundesbank.de/rest/download/BBEX3/D.%s.EUR.BB.AC.000?format=csv&lang=en";

	@PostConstruct
	public void init() {

		RestTemplate restTemplate = new RestTemplate();

		List<Currency> currencyList = currencyRepo.findAll();
		CSVParser parser = new CSVParserBuilder().withSeparator(',').withIgnoreQuotations(true).build();

		for (Currency currency : currencyList) {

			final String url = String.format(URL, currency.getCode());

			RequestEntity<Void> uriComponents;
			try {
				uriComponents = RequestEntity.get(new URI(url)).build();
				ResponseEntity<String> response = restTemplate.exchange(uriComponents, String.class);
				String resp = response.getBody();
				Reader reader = new StringReader(resp);
				CSVReader csvReader = new CSVReaderBuilder(reader).withSkipLines(9).withCSVParser(parser).build();
				String[] line;
				List<CurrencyConversionRates> convertionList = new ArrayList<>();
				while ((line = csvReader.readNext()) != null) {

					if (!line[1].equals(".") && !StringUtils.isEmpty(line[0])) {
						CurrencyConversionRates convertionRate = new CurrencyConversionRates();
						convertionRate.setDate(line[0]);
						convertionRate.setConversionRate(Double.parseDouble(line[1]));
						convertionRate.setCurrencyCode(currency.getCode());
						convertionList.add(convertionRate);
					}
				}
				reader.close();
				csvReader.close();
				conversionRepo.saveAll(convertionList);
			} catch (Exception e) {
				logger.error("Error in loading the exchange rate : ",e);
			}

		}

	}

	public List<Currency> getCurrencies() {

		return currencyRepo.findAll();
	}

	public List<CurrencyConversionRates> getExchangeRates() {

		return conversionRepo.findAll();
	}

	public List<CurrencyConversionRates> getExchangeRates(String date) {

		return conversionRepo.findByDate(date);
	}

	public Double getExchangeRate(String date, String currency, double amount) {

		CurrencyConversionRates convertionRate = conversionRepo.findByDateAndCurrencyCode(date, currency);
		return amount * convertionRate.getConversionRate();
	}

}
