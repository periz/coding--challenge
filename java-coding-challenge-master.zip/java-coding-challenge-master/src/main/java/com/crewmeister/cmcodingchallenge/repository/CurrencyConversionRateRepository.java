package com.crewmeister.cmcodingchallenge.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.crewmeister.cmcodingchallenge.entity.CurrencyConversionRates;

public interface CurrencyConversionRateRepository extends JpaRepository<CurrencyConversionRates, Long> {

	public List<CurrencyConversionRates> findByDate(String date);
	
	public CurrencyConversionRates findByDateAndCurrencyCode(String date, String currencyCode);
}


