package com.crewmeister.cmcodingchallenge.currency;

import java.util.List;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.crewmeister.cmcodingchallenge.entity.Currency;
import com.crewmeister.cmcodingchallenge.entity.CurrencyConversionRates;
import com.crewmeister.cmcodingchallenge.service.CurrencyService;

import io.swagger.annotations.ApiParam;

@RestController()
@RequestMapping("/api")
public class CurrencyController {


	@Autowired
	CurrencyService currencyService;

	@GetMapping("/exchangerates")
	public ResponseEntity<List<CurrencyConversionRates>> getExchangeRates() {

		List<CurrencyConversionRates> currencyConversionRates = currencyService.getExchangeRates();

		return new ResponseEntity<List<CurrencyConversionRates>>(currencyConversionRates, HttpStatus.OK);
	}

	@GetMapping("/currencies")
	public ResponseEntity<List<Currency>> getCurrencies() {

		List<Currency> currency = currencyService.getCurrencies();

		return new ResponseEntity<List<Currency>>(currency, HttpStatus.OK);
	}

	@GetMapping("/exchangerates/{date}")
	public ResponseEntity<List<CurrencyConversionRates>> getCurrenciesByDate(@PathVariable @ApiParam(value = "YYYY-MM-DD", example = "2022-02-26") String date) {

		List<CurrencyConversionRates> currencyConversionRates = currencyService.getExchangeRates(date);

		return new ResponseEntity<List<CurrencyConversionRates>>(currencyConversionRates, HttpStatus.OK);
	}

	@GetMapping("/exchangerate/{date}/{currency}/{amount}")
	public ResponseEntity<Double> getCurrenciesByDateAndCurrency(@PathVariable @ApiParam(value = "YYYY-MM-DD", example = "2022-02-26") String date,
			@PathVariable @ApiParam( example = "INR") String currency, @PathVariable Double amount) {

		Double exchangeAmount = currencyService.getExchangeRate(date, currency, amount);

		return new ResponseEntity<Double>(exchangeAmount, HttpStatus.OK);
	}
	
	@ExceptionHandler({ NullPointerException.class, EntityNotFoundException.class})
    public ResponseEntity<String> handleException() {
        
		return new ResponseEntity<String>("Exchange rate not found", HttpStatus.NOT_FOUND);
		
    }
	
}
