package com.crewmeister.cmcodingchallenge.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.crewmeister.cmcodingchallenge.entity.Currency;

public interface CurrencyRepository extends JpaRepository<Currency, Long> {

}
