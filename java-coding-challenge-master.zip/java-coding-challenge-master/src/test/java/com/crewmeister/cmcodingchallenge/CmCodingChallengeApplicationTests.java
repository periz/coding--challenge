package com.crewmeister.cmcodingchallenge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CmCodingChallengeApplicationTests {

	@Test
	void contextLoads() {
	}

}
